var container = $(".container");

if (!navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry|IEMobile)/)) {
    $(document).on("mousemove",function(e) {  
        var ax = -($(window).innerWidth()/2- e.pageX)/30;
        var ay = ($(window).innerHeight()/2- e.pageY)/20;
        container.attr("style", "transform: rotateY("+ax+"deg) rotateX("+ay+"deg);-webkit-transform: rotateY("+ax+"deg) rotateX("+ay+"deg);-moz-transform: rotateY("+ax+"deg) rotateX("+ay+"deg)");
      });
}