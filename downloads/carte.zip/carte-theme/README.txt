Carte by Klaudia Rozgonyiova
rozgonyiova.com | @effingkay
Free for personal and commercial use under the CCA 3.0 license 


This is Carte, a single page, single screen responsive site template. Super super simples.
If you need a landing page with your contact details that sends folk elsewhere,
this is an ideal solution.

The profile picture used is a portrait by Joe Gardner,
I got from https://unsplash.com/@josephgardnerphotography

Questions/comments/issues = just email or find me on Twitter. Have fun!

Klaudia Rozgonyiova
rozgonyiova.com | @EffingKay

Credits:

	Profile Image:
		Joe Gardner via Unsplash (unsplash.com - CC0 licensed)
			https://unsplash.com/@josephgardnerphotography

	Icons:
		https://www.iconfinder.com/iconsets/liu-square-blac

	Design inspired by:
		Šarūnė Bručaitė's 'Portfolio in progress' via Dribble
            https://dribbble.com/sarunevaldo

License:
    The theme is licensed under the Creative Commons Attribution 4.0 License, which means you can:

        - Use it for personal stuff
        - Use it for commercial stuff
        - Change it however you like
        - You can not remove the back link of rozgonyiova.com
        - You can not redistribute this template
    … all for free, yo! In exchange, just give me an attribution for the template 
    by putting a link to rozgonyiova.com in the footer of your project. Like:

    Template by rozgonyiova.com

    More about license: https://creativecommons.org/licenses/by/4.0/legalcode